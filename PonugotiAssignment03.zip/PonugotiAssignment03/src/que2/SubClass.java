package que2;

public class SubClass extends SuperClass implements InterfaceDemo {
	@Override
	public int A() {
		// TODO Auto-generated method stub
		return super.A();
	}
	@Override
	protected int C() {
		// TODO Auto-generated method stub
		return super.C();
	}
	@Override
	public int I() {
		// TODO Auto-generated method stub
		return InterfaceDemo.super.I();
	}
	
	
}
