package que2;

public class SuperClass {
	
	public final int var1=5;
	
	public int A() {
		return 0;
	}
	private int B() {
		return 0;
	}
	protected int C() {
		return 0;
	}
	
}
