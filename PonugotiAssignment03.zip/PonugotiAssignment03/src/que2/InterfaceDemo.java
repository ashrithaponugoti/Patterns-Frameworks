package que2;

public interface InterfaceDemo {
	
	default int I() {
		return 0;
	}
}
