package que8;

import java.io.IOException;
import java.util.Scanner;

public class tryCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Scanner sc = new Scanner(System.in);
			String s = sc.nextLine();
		}
		finally {
			System.out.println("Nothing");
		}

	}

}
