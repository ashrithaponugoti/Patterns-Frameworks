package que3;

public class SuperClass1 {
	
	public Object A() {
		return null;
	}
	
}
