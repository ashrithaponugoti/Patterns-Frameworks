package que3;

public class SubClass extends SuperClass1 {

	@Override
	public String A() {
		// TODO Auto-generated method stub
		return "Hello";
	}

}
