package que13;

import java.util.ArrayList;
import java.util.Vector;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<String> aList = new ArrayList<>();
		Vector<String> vList = new Vector<>();
		aList.add("Ashritha");
		aList.add("Ponugoti");
		vList.add("Ashritha");
		vList.add("Ponugoti");
		System.out.println(aList);
		System.out.println(vList);
	}
	
}
