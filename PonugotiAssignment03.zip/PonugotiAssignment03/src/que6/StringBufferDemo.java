package que6;

public class StringBufferDemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Ashritha";
		StringBuffer sb = new StringBuffer("Ashritha");
		str = str + "Ponugoti"; //This creates new String object
		sb.append("Ponugoti"); //This modifies the existing StringBuffer Object
		
		System.out.println(str);
		System.out.println(sb);

	}

}
