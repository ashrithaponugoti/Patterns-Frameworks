package que15;

import java.util.HashMap;
import java.util.Hashtable;

public class HashMapHashTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,Integer> hm = new HashMap<>();
		hm.put(1, 10);
		hm.put(2, 20);
		
		for(int i:hm.keySet()) {
			System.out.println(hm.get(i));
		}
		
	}

}
