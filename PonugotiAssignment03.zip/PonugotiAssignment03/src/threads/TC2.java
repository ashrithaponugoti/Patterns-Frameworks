package threads;

public class TC2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
