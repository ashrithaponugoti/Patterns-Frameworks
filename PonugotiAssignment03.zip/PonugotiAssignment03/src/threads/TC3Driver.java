package threads;

public class TC3Driver {

	public static void main(String[] args) {
		Runnable runnable =()->{
			
		};
		
		Thread thread = new Thread(runnable);
		thread.start();
	}

}
