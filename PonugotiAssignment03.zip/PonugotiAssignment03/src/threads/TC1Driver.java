package threads;

public class TC1Driver {
	public static void main(String[] args) {
		TC1 thread = new TC1();
		thread.start();
	}
	
}
