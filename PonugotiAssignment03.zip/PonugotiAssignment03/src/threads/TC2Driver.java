package threads;

public class TC2Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TC2 runnable = 	new TC2();
		Thread thread = new Thread(runnable);
		thread.start();

	}

}
