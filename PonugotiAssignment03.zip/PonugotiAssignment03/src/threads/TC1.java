package threads;

public class TC1 extends Thread {
	public void A() {
		
	}
}

