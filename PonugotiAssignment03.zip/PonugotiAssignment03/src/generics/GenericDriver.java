package generics;

public class GenericDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericDemo<String> gd = new GenericDemo<String>("Ashritha");
		System.out.println(gd.getObj());
		
	}

}
