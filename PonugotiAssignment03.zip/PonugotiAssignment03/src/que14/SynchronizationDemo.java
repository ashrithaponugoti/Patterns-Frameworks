package que14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SynchronizationDemo {
	public static void main(String[] args) {
		ArrayList<String> aList = new ArrayList<>();
		aList.add("abc");
		aList.add("bcd");
		aList.add("Ash");
		aList.add("Ponugoti");
		List<String> synList = Collections.synchronizedList(aList);
		System.out.println(synList);
		synchronized(aList) {
			aList.remove(1);
		}
		
		System.out.println(aList);
	}
	
}
